<?php
session_start();
include_once 'db.php';
$username = "";
$password = "";
$phonenumber = "";
$uid = "";
$name = "";
$vehicletype = "";
$model = "";
$details = "";
$type = "";
$fullname = "";
$id = 0;
$edit_state = false;

if (isset($_POST['save'])) {
  $username = $_POST['username'];
  $password = $_POST['password'];
  $phonenumber = $_POST['phonenumber'];
  $uid = $_POST['uid'];
  $name = $_POST['name'];
  $vehicletype = $_POST['vehicletype'];
  $model = $_POST['model'];
  $details = $_POST['details'];
  $type = $_POST['type'];
  $fullname = $_POST['fullname'];


 $sql = "INSERT INTO usersbike (username,password,phonenumber,uid,name,vehicletype,model,details,type,fullname) VALUES ('$username','$password','$phonenumber','$uid','$name','$vehicletype','$model','$details','$type','$fullname')";
 if (mysqli_query($conn, $sql)) { 
   $_SESSION['message'] = "Data Saved Successfully";
    header("Location: usersbike.php");
   } else {
    mysqli_close($conn);
   }
   
}

// For updating records

if (isset($_POST['update'])) {
  $id = $_POST['id'];
  $username = $_POST['username'];
  $password = $_POST['password'];
  $phonenumber = $_POST['phonenumber'];
  $uid = $_POST['uid'];
  $name = $_POST['name'];
  $vehicletype = $_POST['vehicletype'];
  $model = $_POST['model'];
  $details = $_POST['details'];
  $type = $_POST['type'];
  $fullname = $_POST['fullname'];


  mysqli_query($conn, "UPDATE usersbike SET username='$username', password='$password', phonenumber='$phonenumber', 
  uid='$uid', name='$name', vehicletype='$vehicletype', model='$model', details='$details', type='$type', fullname='$fullname' WHERE id=$id");
  $_SESSION['message'] = "Data Updated Successfully";
  header('location: usersbike.php');
}

// For deleteing records

if (isset($_GET['delete'])) {
  $id = $_GET['delete'];
  mysqli_query($conn, "DELETE FROM usersbike WHERE id=$id");
  $_SESSION['message'] = "Data Deleted Successfully";
  header('location: usersbike.php');
}
?>