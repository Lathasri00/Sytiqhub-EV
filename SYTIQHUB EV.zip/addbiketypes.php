<?php
include 'all_process.php';

if (isset($_GET['edit'])) {
    $id = $_GET['edit'];
    $edit_state = true;
    
    $record = mysqli_query($conn, "SELECT * FROM Biketypes WHERE id=$id");
$data = mysqli_fetch_array($record);
      $Models = $data['Models'];
      $BatteryVoltage = $data['BatteryVoltage'];
      $BatteryAmps = $data['BatteryAmps'];
      $Motorcapacity = $data['Motorcapacity'];
      $Kmph = $data['Kmph'];
      $Modes = $data['Modes'];
      $url = $data['url'];
      $min_vol = $data['min_vol'];
      $max_vol = $data['max_vol'];
  }
?>
<!DOCTYPE html>
<html>
<head>
  <link rel="stylesheet" type="text/css" href="style.css">
  <title>Biketypes</title>
</head>
<body>
<center>
  <?php if (isset($_SESSION['message'])):?>
    <div class="message">
      <?php 
      echo $_SESSION['message']; 
      unset($_SESSION['message']); 
      ?>
    </div>
  <?php endif ?>
  <h1>Biketypes</h1>
   <form class="form-inline" method="POST" action="all_process.php">
     <input type="hidden" name="id" value="<?php echo $id; ?>">
     <input type="text" name="Models" placeholder="Models" value="<?php echo $Models; ?>">
     <input type="int" name="BatteryVoltage" placeholder="Battery Voltage" value="<?php echo $BatteryVoltage; ?>">
     <input type="int" name="BatteryAmps" placeholder="Battery Amps" value="<?php echo $BatteryAmps; ?>">
     <input type="int" name="Motorcapacity" placeholder="Motor Capacity" value="<?php echo $Motorcapacity; ?>">
     <input type="int" name="Kmph" placeholder="Kmph" value="<?php echo $Kmph; ?>">
     <input type="text" name="Modes" placeholder="Modes" value="<?php echo $Modes; ?>">
     <input type="text" name="url" placeholder="Url" value="<?php echo $url; ?>">
     <input type="int" name="min_vol" placeholder="Minimum Voltage" value="<?php echo $min_vol; ?>">
     <input type="int" name="max_vol" placeholder="Maximum Voltage" value="<?php echo $max_vol; ?>">
  <?php if ($edit_state == false): ?>
  <button class="btn" type="submit" name="save" >Save</button>
<?php else: ?>
  <button class="btn" type="submit" name="update" >Update</button>
<?php endif ?>
     
   </form>

<table>
  <tr>
    <th>id</th>
    <th>Models</th>
    <th>BatteryVoltage</th>
    <th>BatteryAmps</th>
    <th>Motorcapacity</th>
    <th>Kmph</th>
    <th>Modes</th>
    <th>url</th>
    <th>min_vol</th>
    <th>max_vol</th>
    <th>Action</th>
  </tr>
  <?php
  $result = mysqli_query($conn, "SELECT * FROM Biketypes");
$i = 1;
while ($row = mysqli_fetch_assoc($result)) {

  ?>
  <tr>
  <td><?php echo $i; ?></td>
  <td><?php echo $row["Models"]; ?></td>
  <td><?php echo $row["BatteryVoltage"]; ?></td>
  <td><?php echo $row["BatteryAmps"]; ?></td>
  <td><?php echo $row["Motorcapacity"]; ?></td>
  <td><?php echo $row["Kmph"]; ?></td>
  <td><?php echo $row["Modes"]; ?></td>
  <td><?php echo $row["url"]; ?></td>
  <td><?php echo $row["min_vol"]; ?></td>
  <td><?php echo $row["max_vol"]; ?></td>

  <td><a href="addbiketypes.php?edit=<?php echo $row["id"]; ?>" class="edit_btn">Edit</a></td>
  <td><a href="all_process.php?delete=<?php echo $row["id"]; ?>" class="del_btn">Delete</a></td>
  </tr>
  <?php
  $i++;
}
  ?>
</table>

</center>


</body>
</html>