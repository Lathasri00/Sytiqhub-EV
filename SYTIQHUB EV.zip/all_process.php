<?php
session_start();
include_once 'db.php';
$Models = "";
$BatteryVoltage = "";
$BatteryAmps = "";
$Motorcapacity = "";
$Kmph = "";
$Modes = "";
$url = "";
$min_vol = "";
$max_vol = "";
$id = 0;
$edit_state = false;

if (isset($_POST['save'])) {
  $Models = $_POST['Models'];
  $BatteryVoltage = $_POST['BatteryVoltage'];
  $BatteryAmps = $_POST['BatteryAmps'];
  $Motorcapacity = $_POST['Motorcapacity'];
  $Kmph = $_POST['Kmph'];
  $Modes = $_POST['Modes'];
  $url = $_POST['url'];
  $min_vol = $_POST['min_vol'];
  $max_vol = $_POST['max_vol'];


 $sql = "INSERT INTO Biketypes (Models,BatteryVoltage,BatteryAmps,Motorcapacity,Kmph,Modes,url,min_vol,max_vol) VALUES ('$Models','$BatteryVoltage','$BatteryAmps','$Motorcapacity','$Kmph','$Modes','$url','$min_vol','$max_vol')";
 if (mysqli_query($conn, $sql)) { 
   $_SESSION['message'] = "Data Saved Successfully";
    header("Location: addbiketypes.php");
   } else {
    mysqli_close($conn);
   }
   
}

// For updating records

if (isset($_POST['update'])) {
  $id = $_POST['id'];
  $Models = $_POST['Models'];
  $BatteryVoltage = $_POST['BatteryVoltage'];
  $BatteryAmps = $_POST['BatteryAmps'];
  $Motorcapacity = $_POST['Motorcapacity'];
  $Kmph = $_POST['Kmph'];
  $Modes = $_POST['Modes'];
  $url = $_POST['url'];
  $min_vol = $_POST['min_vol'];
  $max_vol = $_POST['max_vol'];


  mysqli_query($conn, "UPDATE Biketypes SET Models='$Models', BatteryVoltage='$BatteryVoltage', BatteryAmps='$BatteryAmps', Motorcapacity='$Motorcapacity', Kmph='$Kmph', Modes='$Modes', url='$url', min_vol='$min_vol', max_vol='$max_vol' WHERE id=$id");
  $_SESSION['message'] = "Data Updated Successfully";
  header('location: addbiketypes.php');
}

// For deleteing records

if (isset($_GET['delete'])) {
  $id = $_GET['delete'];
  mysqli_query($conn, "DELETE FROM Biketypes WHERE id=$id");
  $_SESSION['message'] = "Data Deleted Successfully";
  header('location:addbiketypes.php');
}
?>