<?php
include 'process.php';

if (isset($_GET['edit'])) {
    $id = $_GET['edit'];
    $edit_state = true;
    
    $record = mysqli_query($conn, "SELECT * FROM usersbike WHERE id=$id");
$data = mysqli_fetch_array($record);
  $username = $data['username'];
  $password = $data['password'];
  $phonenumber = $data['phonenumber'];
  $uid = $data['uid'];
  $name = $data['name'];
  $vehicletype = $data['vehicletype'];
  $model = $data['model'];
  $details = $data['details'];
  $type = $data['type'];
  $fullname = $data['fullname'];
  }
?>
<!DOCTYPE html>
<html>
<head>
  <link rel="stylesheet" type="text/css" href="style.css">
  <title>UsersBikeData</title>
</head>
<body>
<center>
  <?php if (isset($_SESSION['message'])):?>
    <div class="message">
      <?php 
      echo $_SESSION['message']; 
      unset($_SESSION['message']); 
      ?>
    </div>
  <?php endif ?>
  <h1>UsersBikeData</h1>
   <form class="form-inline" method="POST" action="process.php">
     <input type="hidden" name="id" value="<?php echo $id; ?>">
     <input type="text" name="username" placeholder="Username" value="<?php echo $username; ?>">
     <input type="text" name="password" placeholder="Password" value="<?php echo $password; ?>">
     <input type="text" name="phonenumber" placeholder="Mobile Number" value="<?php echo $phonenumber; ?>">
     <input type="text" name="uid" placeholder="User Id" value="<?php echo $uid; ?>">
     <input type="text" name="name" placeholder="Name" value="<?php echo $name; ?>">
     <input type="text" name="vehicletype" placeholder="Vehicle Type" value="<?php echo $vehicletype; ?>">
     <input type="text" name="model" placeholder="Model" value="<?php echo $model; ?>">
     <input type="text" name="details" placeholder="Details" value="<?php echo $details; ?>">
     <input type="text" name="type" placeholder="Type" value="<?php echo $type; ?>">
     <input type="text" name="fullname" placeholder="Fullname" value="<?php echo $fullname; ?>">
  <?php if ($edit_state == false): ?>
  <button class="btn" type="submit" name="save" >Save</button>
<?php else: ?>
  <button class="btn" type="submit" name="update" >Update</button>
<?php endif ?>
     
   </form>

<table>
  <tr>
    <th>id</th>
    <th>username</th>
    <th>password</th>
    <th>phonenumber</th>
    <th>uid</th>
    <th>name</th>
    <th>vehicletype</th>
    <th>model</th>
    <th>details</th>
    <th>type</th>
    <th>fullname</th>
    <th>Action</th>
  </tr>
  <?php
  $result = mysqli_query($conn, "SELECT * FROM usersbike");
$i = 1;
while ($row = mysqli_fetch_assoc($result)) {

  ?>
  <tr>
  <td><?php echo $i; ?></td>
  <td><?php echo $row["username"]; ?></td>
  <td><?php echo $row["password"]; ?></td>
  <td><?php echo $row["phonenumber"]; ?></td>
  <td><?php echo $row["uid"]; ?></td>
  <td><?php echo $row["name"]; ?></td>
  <td><?php echo $row["vehicletype"]; ?></td>
  <td><?php echo $row["model"]; ?></td>
  <td><?php echo $row["details"]; ?></td>
  <td><?php echo $row["type"]; ?></td>
  <td><?php echo $row["fullname"]; ?></td>

  <td><a href="usersbike.php?edit=<?php echo $row["id"]; ?>" class="edit_btn">Edit</a></td>
  <td><a href="process.php?delete=<?php echo $row["id"]; ?>" class="del_btn">Delete</a></td>
  </tr>
  <?php
  $i++;
}
  ?>
</table>

</center>


</body>
</html>