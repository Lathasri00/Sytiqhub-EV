<?php
$servername = "localhost";
$username = "id17212219_09876";
$password = "O|tlJ@Lze5P!I#ck";
$dbname = "id17212219_0987";

// Create connection

$conn =  mysqli_connect($servername,$username,$password,"$dbname");

if (!$conn) {
  
  die("Could Not Connect:" .mysqli_connect_error());
}




?>